const mongoose = require('mongoose');

const FacultySchema = new mongoose.Schema({
    Name: {
        type: String,
        required: true
    },
    Subject: {
        type: String,
        required: true
    },
    Rating: {
        type: Number,
        required: true
    },
    Department: {
        type: String,
        required: true
    },
})

module.exports = mongoose.model('Student_server', FacultySchema);

