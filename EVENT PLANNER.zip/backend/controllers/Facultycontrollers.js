const FacultySchema = require('../models/Facultymodel');

module.exports.getfacultylist = async (req, res) => {
    try {
        const facultylist = await FacultySchema.find();
        res.send(facultylist);
    } catch (error) {
        console.error("Error fetching faculty list:", error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

module.exports.addNewFaculty = async (req, res) => {
    const { Name, Subject, Rating, Department  } = req.body;

    
    try {
        const newFaculty = await FacultySchema.create({
            Name,
            Subject,
            Rating,
            Department,
        });

        console.log("Added new Faculty:", newFaculty);
        res.status(201).json(newFaculty);
    } catch (error) {
        console.error("Error adding new Faculty:", error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

module.exports.updateFaculty = async (req, res) => {
    const { id } = req.params.id; 
    const { Name, Subject, Rating, Department } = req.body;

    try {
        const updatedFaculty = await FacultySchema.findByIdAndUpdate(
            id, 
            { Name, Subject, Rating, Department },
            { new: true } 
        );

        if (!updatedFaculty) {
            return res.status(404).json({ error: 'Faculty not found' }); 
        }

        console.log("Updated Faculty:", updatedFaculty);
        res.status(200).send("Updated Successfully");
    } catch (error) {
        console.error("Error updating :", error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

module.exports.deleteFaculty = async (req, res) => {
    const { id } = req.params; 
    try {
        const result = await FacultySchema.findByIdAndDelete(id);

        if (!result) {
            return res.status(404).json({ error: 'Faculty not found' }); // Handle case where task does not exist
        }

        res.status(200).send("Deleted Successfully");
    } catch (error) {
        console.error("Error deleting task:", error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

module.exports.singleFaculty = async (req, res) => {
    const { id } = req.params;


    try {
        const Faculty = await FacultySchema.findById(id);
        if (!Faculty) {
            return res.status(404).send('Faculty not found');
        }
        res.json(Faculty);
    } catch (error) {
        console.error("Error fetching Faculty:", error);
        res.status(500).send('Internal Server Error');
    }
};


