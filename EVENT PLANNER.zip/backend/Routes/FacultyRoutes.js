const {Router} = require('express');
const { getfacultylist, addNewFaculty, updateFaculty, deleteFaculty, singleFaculty} = require('../controllers/Facultycontrollers');



const router = Router();

router.get('/facultylist', getfacultylist);
router.post('/newfaculty', addNewFaculty);
router.put('/faculty/:id', updateFaculty)
router.get('/faculty/:id', singleFaculty)
router.delete('/faculty/:id', deleteFaculty)


module.exports = router;