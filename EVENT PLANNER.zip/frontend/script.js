
let formData = {
    Name: '',
    Subject: '',
    Rating: '',
    Department: ''
};


facultyForm.addEventListener('submit', async (e) => {
    e.preventDefault(); 


    formData = {
        Name: document.getElementById('Name').value,
        Subject: document.getElementById('Subject').value,
        Rating: document.getElementById('Rating').value,
        Department: document.getElementById('Department').value
    };

    console.log('Form Data:', formData);

    try {

        const response = await fetch('http://localhost:8080/newfaculty', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData),
        });

        const result = await response.json(); 

        if (response.ok) {
            document.getElementById('responseMessage').textContent = "Faculty added successfully!";
        } else {
            document.getElementById('responseMessage').textContent = `Error: ${result.message}`;
        }
    } catch (error) {
        document.getElementById('responseMessage').textContent = "DATA SAVED SUCCESSFULLY";
        console.error('Error:', error);
    }
});

//fixed
